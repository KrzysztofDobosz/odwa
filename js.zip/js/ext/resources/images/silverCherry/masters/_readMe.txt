Copies of the images of this theme that contain elements of color have been stored here for easy manipulation of future styles.

